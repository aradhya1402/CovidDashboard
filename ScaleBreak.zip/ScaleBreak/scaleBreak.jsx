import React from "react";
import { Bar } from "react-chartjs-2";
import { useState, useEffect } from "react";
function ScaleBreak(props) {
  const [scaleBreakData, setScaleBreakData] = useState([]);
  const [showScaleBreak, setShowScaleBreak] = useState(false);
  const [barChartData, setChartData] = useState([]);
  const median = (values) => {
    if (values.length === 0) return 0;

    values.sort(function (a, b) {
      return a - b;
    });

    var half = Math.floor(values.length / 2);

    if (values.length % 2) return values[half];

    return (values[half - 1] + values[half]) / 2.0;
  };
  useEffect(() => {
    let chartData = props.chartData;
    let dummyChartData = [...props.chartData];
    let medianChartData = [...props.chartData];
    let medianValue = median(medianChartData);
    let scaleBreakData = [];
    let indexArray = [];
    let scaleBreakDateCount = 0;
    for (let i = 0; i < chartData.length; i++) {
      console.log(chartData[i] / medianValue);
      if (chartData[i] / medianValue >= 10) {
        scaleBreakData.push(chartData[i]);
        indexArray.push(i);
        scaleBreakDateCount++;
      } else {
        scaleBreakData.push(0);
      }
    }
    while (indexArray.length > 0) {
      dummyChartData.splice(indexArray[0], 1);
      indexArray.map((item) => item - 1);
      indexArray.shift();
    }
    let secondMax = Math.max(...dummyChartData);
    chartData = chartData.map((item) => (item > secondMax ? secondMax : item));
    setChartData(chartData);
    if (scaleBreakDateCount > 0) {
      setScaleBreakData(scaleBreakData);
      setShowScaleBreak(true);
    }
  }, props.chartData);

  var chartData = {
    labels: props.chartLabels,
    datasets: [
      {
        label: props.chartLabel,
        backgroundColor: "#ffbc3a",
        borderColor: "#ffbc3a",
        borderWidth: 1,
        data: barChartData,
      },
    ],
  };
  var chartData2 = {
    labels: props.chartLabels,
    datasets: [
      {
        label: props.chartLabel,
        backgroundColor: "#ffbc3a",
        borderColor: "#ffbc3a",
        borderWidth: 1,
        data: scaleBreakData,
      },
    ],
  };
  var chartOptions = {
    plugins: {
      labels: {
        display: false,
        render: "value",
        precision: 2,
        position: "border",
        fontColor: "rgba(0,0,0,0)",
      },
    },
    layout: {
      padding: {
        left: 30,
      },
    },
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      xAxes: [
        {
          barPercentage: 1,
          ticks: {
            min: 0,
            callback: (value) => {
              return value.substring(0, 5);
            },
            minRotation: 0,
            maxRotation: 0,
          },
          gridLines: {
            display: false,
            color: "rgba(0, 0, 0, 0)",
          },
        },
      ],
      yAxes: [
        {
          barPercentage: 1,
          ticks: {
            max: props.chartData.sort()[props.chartData.length - 2],
          },
          gridLines: {
            display: false,
            color: "rgba(0, 0, 0, 0)",
          },
        },
      ],
    },
    hover: {
      animationDuration: 0,
    },
    animation: {
      duration: 0,
    },
    legend: {
      display: false,
    },
    tooltips: {
      enabled: false,
    },
  };
  var chartOptions2 = {
    plugins: {
      labels: {
        display: false,
        render: "value",
        precision: 2,
        position: "border",
        fontColor: "rgba(0,0,0,0)",
      },
    },
    layout: {
      padding: {
        left: 10,
      },
    },
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      xAxes: [
        {
          display: false,
          barPercentage: 1,
          ticks: {
            min: 0,
          },
          gridLines: {
            display: false,
            color: "rgba(0, 0, 0, 0)",
          },
        },
      ],
      yAxes: [
        {
          barPercentage: 1,
          ticks: {
            min: Math.max(...scaleBreakData) - 2,
            max: Math.max(...scaleBreakData),
            stepSize: 20,
            callback: (value) => {
              return Math.round(value);
            },
          },
          gridLines: {
            display: false,
            color: "rgba(0, 0, 0, 0)",
          },
        },
      ],
    },
    hover: {
      animationDuration: 0,
    },
    animation: {
      duration: 0,
    },
    legend: {
      display: false,
    },
    tooltips: {
      enabled: false,
    },
  };
  return (
    <>
      <div style={{ height: "20%" }}>
        {" "}
        {showScaleBreak && <Bar data={chartData2} options={chartOptions2} />}
      </div>
      <div style={{ paddingLeft: "30px" }}>==</div>
      <div style={{ height: "80%" }}>
        {" "}
        {<Bar data={chartData} options={chartOptions} />}
      </div>
    </>
  );
}
export default ScaleBreak;
