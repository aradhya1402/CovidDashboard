import * as d3 from 'd3';
import React, { useRef, useEffect,useState } from 'react';
import './MembersAndMeasured.css';

const dataset =  {
"name":"diseases",
"children":
[
  {
    "name":"General Health + Prevention",
    "value":"1250",
   
  },
  {
    "name":"Diabetics",
    "value":"620",
   
  },
  {
    "name":"Respiratory",
    "value":"600",
   
  },
  {
    "name":"Respiratory",
    "value":"600",
   
  },
  {
    "name":"Musculoskeletal, Pain",
    "value":"450",
   
  },
  {
    "name":"Behavioural Health",
    "value":"500",
   
  },
  {
    "name":"Other/ At Risk + Chronic",
    "value":"250",
   
  },
  {
    "name":"Cancer",
    "value":"210",
   
  },
  {
    "name":"Cardiovascular",
    "value":"200",
   
  }
  ]
};

function Treemap() {

  const [toggleState, setToggleState] = useState("off");

    const toggle=()=> {
        setToggleState(toggleState === "off" ? "on" : "off");
    }

  const ref = useRef();
  useEffect(() => {
    const svg = d3.select(ref.current)
        .attr("width", 600)
        .attr("height", 307)
       
}, []);

useEffect(() => {
    draw();
},);

const draw = () => {

  const svg = d3.select(ref.current);

        // Give the data to this cluster layout:
        var root = d3.hierarchy(dataset).sum(function(d){ return d.value});

        // initialize treemap
        d3.treemap()
            .size([600, 307])
            .paddingTop(28)
            .paddingRight(7)
            .paddingInner(3)
            (root);
        
        
            const color = d3.scaleLinear()
                          .domain([0,9])
                          .range(["#003B6D", "#6EB8F7"]);

          
        // Select the nodes
        var nodes = svg
                    .selectAll("rect")
                    .data(root.leaves())

        // draw rectangles
        nodes.enter()
            .append("rect")
            .attr('x', function (d) { return d.x0; })
            .attr('y', function (d) { return d.y0; })
            .attr('width', function (d) { return d.x1 - d.x0; })
            .attr('height', function (d) { return d.y1 - d.y0; })
            .style("fill", function(d,i){ return color(i)} )

        // select node titles
        var nodeText = svg
            .selectAll("text")
            .data(root.leaves())

        // add the text
        nodeText.enter()
            .append("text")
            
            .attr("x", function(d){ return d.x0+5})    // +10 to adjust position (more right)
            .attr("y", function(d){ return d.y0+20})    // +20 to adjust position (lower)
            .text(function(d){ return d.data.name})
            .attr("font-size", "15px")
            .attr("fill", "white")
        
        // select node titles
        var nodeVals = svg
            .selectAll("vals")
            .data(root.leaves())  

        // add the values
        nodeVals.enter()
            .append("text")
            .attr("x", function(d){ return d.x0+5})    // +10 to adjust position (more right)
            .attr("y", function(d){ return d.y0+35})    // +20 to adjust position (lower)
            .text(function(d){ return d.data.value })
            .attr("font-size", "11px")
            .attr("fill", "white")
      }
  return (

    <div className="members-component">
    <div className="member-headers">
        <div className="member-heading">Members and Measured Care Gaps</div>
       
        <div className="members-measured-toggle">
            <div className="members-toggle">Members</div>
            <div className={`switch ${toggleState}`} onClick={toggle}> </div>
            <div className= "measured-toggle">Measured Care Gaps</div>
        </div>
    </div>
    <div className="low-high-gradient">
            <div className="low-gradient">Low</div>
            <div className="gradient"></div>
            <div className="high-gradient">High</div>
        </div>
    <div className="treemap">
            <svg ref={ref}>
            </svg>
        </div>
      </div>
  );
}
export default Treemap;